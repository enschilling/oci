import logging
import json
import os
import time
from pathlib import Path

import httpx
from dotenv import load_dotenv
from oci_genai_auth import OciResourcePrincipalAuth, OciUserPrincipalAuth
from openai import OpenAI

from oci_iam_auth import (
    DEFAULT_OCI_AUTH_MODE,
    DEFAULT_OCI_CONFIG_FILE,
    DEFAULT_OCI_CONFIG_PROFILE,
)
from response_content import latest_response_input, messages_include_images
from semantic_sql_tool import query_database


APP_DIR = Path(__file__).parent
load_dotenv(APP_DIR / ".env")

logger = logging.getLogger("oci-llm-chat")
DEFAULT_MAX_OUTPUT_TOKENS = 10000
DEFAULT_SQL_MAX_ROWS = 50
DEFAULT_SQL_TIMEOUT_SECONDS = 30
DEFAULT_GUARDRAILS_LANGUAGE_CODE = "en"
DEFAULT_GUARDRAILS_PROMPT_INJECTION_THRESHOLD = 1.0
SQL_TOOL_NAME = "query_construction_data"
MAX_TOOL_ROUNDS = 3
KNOWN_TEXT_ONLY_IMAGE_MODELS = {"openai.gpt-oss-120b"}
CONSTRUCTION_ENGINEERING_SYSTEM_PROMPT = (
    "You are the Seer Construction Group decision-readiness assistant. Answer only questions about "
    "construction projects, suppliers, schedules, purchasing, inspections, compliance, engineering "
    "documents, and evidence. Use query_construction_data for governed SQL facts from the Gold products. "
    "Use file_search for specifications, supplier agreements, inspection reports, and construction policy. "
    "Treat Bronze source records as preserved evidence, Silver as reconciled entities, and Gold products as "
    "the stable contract for answers. Explain supplier recommendations with the supporting project, schedule, "
    "inspection, certification, NCR, and document evidence. Use READY or RECOMMENDED for complete evidence; "
    "REQUEST_INFORMATION or CONDITIONAL when follow-up is required; and DENIED or NOT_READY when blockers "
    "remain. Do not invent evidence, certifications, or approvals. If a tool returns no_rows, not_answerable, "
    "or an error, state that the governed data does not contain enough evidence. Refuse out-of-scope requests briefly."
)
PROJECT_CONTEXT_PROMPT = (
    "\n\nActive construction project context:\n"
    "- Scope governed SQL retrieval to project_code = '{project_code}'.\n"
    "- Do not widen the query to another project unless the user changes the selected project.\n"
    "- Keep provenance visible: identify source records or documents supporting a recommendation."
)


def env(name, default=""):
    return os.getenv(name, default).strip()


def int_env(name, default):
    try:
        return int(env(name, str(default)))
    except ValueError:
        logger.warning("Invalid integer for %s; using %s", name, default)
        return default


def float_env(name, default):
    try:
        return float(env(name, str(default)))
    except ValueError:
        logger.warning("Invalid float for %s; using %s", name, default)
        return default


def bool_env(name, default=False):
    raw = env(name, str(default)).lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    logger.warning("Invalid boolean for %s; using %s", name, default)
    return default


def list_env(name, default=None):
    raw = env(name)
    if not raw:
        return list(default or [])
    return [item.strip() for item in raw.split(",") if item.strip()]


def settings():
    region = env("OCI_GENAI_REGION")
    adb_mcp_region = env("OCI_ADB_MCP_REGION")
    return {
        "region": region,
        "project_ocid": env("OCI_GENAI_PROJECT_OCID", env("OCI_GENAI_PROJECT_ID")),
        "model": env("OCI_GENAI_MODEL"),
        "cheaper_model": env("OCI_GENAI_CHEAPER_MODEL"),
        "model_routing_enabled": bool_env("OCI_GENAI_MODEL_ROUTING_ENABLED"),
        "oci_auth_mode": env("OCI_AUTH_MODE", DEFAULT_OCI_AUTH_MODE),
        "oci_config_file": os.path.expandvars(env("OCI_CONFIG_FILE", DEFAULT_OCI_CONFIG_FILE)),
        "oci_config_profile": env("OCI_CONFIG_PROFILE", DEFAULT_OCI_CONFIG_PROFILE),
        "max_output_tokens": int_env("OCI_GENAI_MAX_OUTPUT_TOKENS", DEFAULT_MAX_OUTPUT_TOKENS),
        "guardrails_compartment_ocid": env("OCI_GENAI_GUARDRAILS_COMPARTMENT_OCID"),
        "guardrails_language_code": env(
            "OCI_GENAI_GUARDRAILS_LANGUAGE_CODE",
            DEFAULT_GUARDRAILS_LANGUAGE_CODE,
        ),
        "guardrails_prompt_injection_threshold": float_env(
            "OCI_GENAI_GUARDRAILS_PROMPT_INJECTION_THRESHOLD",
            DEFAULT_GUARDRAILS_PROMPT_INJECTION_THRESHOLD,
        ),
        "vector_store_ids": list_env("OCI_GENAI_VECTOR_STORE_IDS"),
        "semantic_store_ocid": env("OCI_GENAI_SEMANTIC_STORE_OCID"),
        "nl2sql_region": env("OCI_GENAI_NL2SQL_REGION", region),
        "nl2sql_api_version": env("OCI_GENAI_NL2SQL_API_VERSION", "20260325"),
        "adb_mcp_region": adb_mcp_region,
        "adb_database_ocid": env("OCI_ADB_DATABASE_OCID"),
        "adb_mcp_username": env("OCI_ADB_MCP_USERNAME"),
        "adb_mcp_password": env("OCI_ADB_MCP_PASSWORD"),
        "adb_mcp_password_secret_ocid": env("OCI_ADB_MCP_PASSWORD_SECRET_OCID"),
        "adb_mcp_password_secret_region": env(
            "OCI_ADB_MCP_PASSWORD_SECRET_REGION",
            adb_mcp_region,
        ),
        "adb_mcp_execute_tool": env("OCI_ADB_MCP_EXECUTE_TOOL", "EXECUTE_SQL"),
        "adb_mcp_sql_argument": env("OCI_ADB_MCP_SQL_ARGUMENT", "query"),
        "adb_mcp_offset_argument": env("OCI_ADB_MCP_OFFSET_ARGUMENT", "offset"),
        "adb_mcp_limit_argument": env("OCI_ADB_MCP_LIMIT_ARGUMENT", "limit"),
        "sql_max_rows": int_env("OCI_SQL_MAX_ROWS", DEFAULT_SQL_MAX_ROWS),
        "sql_timeout_seconds": int_env("OCI_SQL_TIMEOUT_SECONDS", DEFAULT_SQL_TIMEOUT_SECONDS),
    }


def make_client(region, project_ocid, config_file, config_profile, auth_mode=DEFAULT_OCI_AUTH_MODE):
    base_url = f"https://inference.generativeai.{region}.oci.oraclecloud.com/openai/v1"
    normalized_auth_mode = (auth_mode or DEFAULT_OCI_AUTH_MODE).strip().lower().replace("-", "_")
    if normalized_auth_mode == "resource_principal":
        auth = OciResourcePrincipalAuth()
    elif normalized_auth_mode == "config_file":
        auth = OciUserPrincipalAuth(
            config_file=config_file,
            profile_name=config_profile,
        )
    else:
        raise ValueError("OCI_AUTH_MODE must be 'config_file' or 'resource_principal'.")

    options = {
        "base_url": base_url,
        "project": project_ocid,
        "http_client": httpx.Client(auth=auth),
    }
    options["api" + "_" + "key"] = "not-used"
    return OpenAI(**options)


def create_conversation(client):
    conversation = client.conversations.create()
    conversation_id = value(conversation, "id", "")
    if not conversation_id:
        raise RuntimeError("OCI did not return a conversation id.")
    return conversation_id


def response_text(response):
    text = value(response, "output_text", "") or ""
    output_text = "".join(text_from_item(item) for item in value(response, "output", []) or [])
    return output_text if len(output_text) > len(text) else text


def text_from_item(item):
    chunks = []
    direct_text = value(item, "text", "") or ""
    if direct_text:
        chunks.append(direct_text)

    for part in value(item, "content", []) or []:
        chunks.append(value(part, "text", "") or "")
    return "".join(chunks)


def value(item, name, default=None):
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def response_options(model, prompt, cfg, messages=None, conversation_id=None):
    model = response_model(model, cfg, messages)
    if not conversation_id:
        raise ValueError("conversation_id is required.")
    options = {
        "model": model,
        "instructions": response_instructions(cfg),
        "input": latest_response_input(messages, prompt),
        "tools": response_tools(cfg),
        "conversation": conversation_id,
    }
    if cfg["max_output_tokens"] > 0:
        options["max_output_tokens"] = cfg["max_output_tokens"]

    return options


def response_model(model, cfg, messages=None):
    if cfg.get("model_routing_enabled") and not messages_include_images(messages):
        model = cfg.get("cheaper_model") or model

    if model in KNOWN_TEXT_ONLY_IMAGE_MODELS and messages_include_images(messages):
        raise ValueError(f"Model {model} does not support image input.")

    return model


def response_instructions(cfg):
    project_code = cfg.get("project_code")
    if project_code in (None, ""):
        return CONSTRUCTION_ENGINEERING_SYSTEM_PROMPT
    return CONSTRUCTION_ENGINEERING_SYSTEM_PROMPT + PROJECT_CONTEXT_PROMPT.format(
        project_code=project_code,
    )


def response_tools(cfg):
    tools = [sql_tool_definition(cfg.get("project_code"))]
    vector_store_ids = cfg.get("vector_store_ids") or []
    if vector_store_ids:
        tools.append(
            {
                "type": "file_search",
                "vector_store_ids": vector_store_ids
            }
        )
    return tools


def sql_tool_definition(project_code=None):
    description = (
        "Query governed construction Gold views for project context, supplier recommendations, supplier profiles, "
        "document catalog, and document provenance. Use only for project, supplier, schedule, purchase order, "
        "inspection, certification, NCR, compliance, and decision-readiness facts."
    )
    if project_code not in (None, ""):
        description += (
            f" Database access is scoped to project_code {project_code}."
        )

    return {
        "type": "function",
        "name": SQL_TOOL_NAME,
        "description": description,
        "parameters": {
            "type": "object",
            "required": ["question"],
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The user's database-backed question.",
                }
            },
            "additionalProperties": False,
        },
    }


def stream_response(
    client,
    model,
    prompt,
    cfg,
    messages=None,
    status_callback=None,
    conversation_id=None,
):
    model = response_model(model, cfg, messages)
    model_label = model or "not configured"
    notify_status(status_callback, f"Sending prompt to LLM ({model_label})...")
    response = client.responses.create(
        **response_options(model, prompt, cfg, messages, conversation_id)
    )
    notify_status(status_callback, f"Received response from LLM ({model_label}).")
    response = complete_tool_calls(
        client,
        response,
        model,
        cfg,
        prompt,
        messages,
        status_callback,
        conversation_id,
    )
    notify_status(status_callback, f"Received final response from LLM ({model_label}).")
    text = response_text(response)

    ensure_completed_response(response)

    if not text:
        logger.error("OCI completed response did not contain text: %s", response)
        raise RuntimeError("OCI completed the response without returning text.")

    for end in range(24, len(text) + 24, 24):
        yield text[:end]
        time.sleep(0.01)


def complete_tool_calls(
    client,
    response,
    model,
    cfg,
    prompt,
    messages=None,
    status_callback=None,
    conversation_id=None,
):
    for _round in range(MAX_TOOL_ROUNDS):
        ensure_completed_response(response)
        calls = sql_function_calls(response)
        if not calls:
            return response

        tool_outputs = [
            function_call_output(call, cfg, status_callback) for call in calls
        ]
        model_label = model or "not configured"
        notify_status(status_callback, f"Sending retrieved data back to LLM ({model_label})...")
        options = tool_response_options(
            model,
            cfg,
            tool_outputs,
            conversation_id,
        )

        response = client.responses.create(**options)
        notify_status(status_callback, f"Received response from LLM ({model_label}).")

    raise RuntimeError("OCI response exceeded the maximum SQL tool-call rounds.")


def tool_response_options(model, cfg, tool_outputs, conversation_id=None):
    if not conversation_id:
        raise ValueError("conversation_id is required.")
    options = {
        "model": model,
        "instructions": response_instructions(cfg),
        "input": tool_outputs,
        "tools": response_tools(cfg),
        "conversation": conversation_id,
    }
    if cfg["max_output_tokens"] > 0:
        options["max_output_tokens"] = cfg["max_output_tokens"]
    return options


def function_call_output(call, cfg, status_callback=None):
    if call["name"] != SQL_TOOL_NAME:
        result = {
            "status": "execution_error",
            "message": f"Unknown function call: {call['name']}",
            "columns": [],
            "rows": [],
            "truncated": False,
        }
    else:
        arguments = parse_arguments(call["arguments"])
        question = arguments.get("question") or arguments.get("query") or ""
        if not question:
            result = {
                "status": "execution_error",
                "message": "Missing required question argument.",
                "columns": [],
                "rows": [],
                "truncated": False,
            }
        else:
            notify_status(status_callback, "Calling SQL retrieval tool...")
            if status_callback:
                result = query_database(question, cfg, status_callback=status_callback)
            else:
                result = query_database(question, cfg)

    return {
        "type": "function_call_output",
        "call_id": call["call_id"],
        "output": json.dumps(result, default=str),
    }


def sql_function_calls(response):
    calls = []
    for item in value(response, "output", []) or []:
        item_type = value(item, "type")
        name = value(item, "name")
        if item_type != "function_call" or not name:
            continue
        calls.append(
            {
                "name": name,
                "call_id": value(item, "call_id") or value(item, "id"),
                "arguments": value(item, "arguments", "{}") or "{}",
            }
        )
    return calls


def parse_arguments(raw_arguments):
    if isinstance(raw_arguments, dict):
        return raw_arguments
    try:
        return json.loads(raw_arguments or "{}")
    except json.JSONDecodeError:
        return {}


def ensure_completed_response(response):
    if value(response, "status", "") != "completed":
        details = value(response, "incomplete_details")
        reason = value(details, "reason", "unknown")
        logger.error("OCI response did not complete (%s): %s", reason, response)
        raise RuntimeError(f"OCI response did not complete: {reason}")


def notify_status(status_callback, message):
    logger.info(message)
    if status_callback:
        status_callback(message)
