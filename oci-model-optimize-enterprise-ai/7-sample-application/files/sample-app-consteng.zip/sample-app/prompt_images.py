import base64
from dataclasses import dataclass
from pathlib import PurePath


DEFAULT_FILENAME = "uploaded-image"
MAX_IMAGE_BYTES = 7 * 1024 * 1024
SUPPORTED_IMAGE_MIME_TYPES = {
    "image/png": (".png",),
    "image/jpeg": (".jpg", ".jpeg"),
    "image/webp": (".webp",),
}
EXTENSION_MIME_TYPES = {
    extension: mime_type
    for mime_type, extensions in SUPPORTED_IMAGE_MIME_TYPES.items()
    for extension in extensions
}
MIME_TYPE_ALIASES = {
    "image/jpg": "image/jpeg",
    "image/pjpeg": "image/jpeg",
}


class PromptImageError(ValueError):
    pass


@dataclass(frozen=True)
class PromptImage:
    filename: str
    content: bytes
    mime_type: str

    @property
    def size(self):
        return len(self.content)

    @property
    def data_url(self):
        payload = base64.b64encode(self.content).decode("ascii")
        return f"data:{self.mime_type};base64,{payload}"

    def as_dict(self):
        return {
            "filename": self.filename,
            "mime_type": self.mime_type,
            "size": self.size,
            "data_url": self.data_url,
        }

    def display_ref(self):
        return {
            "filename": self.filename,
            "mime_type": self.mime_type,
            "size": self.size,
        }


def capture_uploaded_image(uploaded_file):
    if uploaded_file is None:
        return None

    filename = safe_filename(getattr(uploaded_file, "name", ""))
    content = uploaded_file.getvalue()
    uploaded_mime_type = normalize_mime_type(getattr(uploaded_file, "type", ""))
    mime_type = validated_image_mime_type(filename, content, uploaded_mime_type)

    return PromptImage(
        filename=filename,
        content=content,
        mime_type=mime_type,
    )


def validated_image_mime_type(filename, content, uploaded_mime_type=""):
    if not content:
        raise PromptImageError("Uploaded image is empty.")

    if len(content) > MAX_IMAGE_BYTES:
        raise PromptImageError(
            f"Uploaded image is too large. Maximum size is {format_file_size(MAX_IMAGE_BYTES)}."
        )

    extension_mime_type = mime_type_from_extension(filename)
    if not extension_mime_type:
        raise PromptImageError("Unsupported image type. Upload PNG, JPEG, or WebP.")

    sniffed_mime_type = sniff_image_mime_type(content)
    if not sniffed_mime_type:
        raise PromptImageError("Uploaded file content is not a supported image.")

    if uploaded_mime_type and uploaded_mime_type != sniffed_mime_type:
        raise PromptImageError("Uploaded image MIME type does not match its content.")

    if extension_mime_type != sniffed_mime_type:
        raise PromptImageError("Uploaded image extension does not match its content.")

    return sniffed_mime_type


def normalize_mime_type(mime_type):
    normalized = (mime_type or "").split(";", 1)[0].strip().lower()
    return MIME_TYPE_ALIASES.get(normalized, normalized)


def mime_type_from_extension(filename):
    suffix = PurePath(filename).suffix.lower()
    return EXTENSION_MIME_TYPES.get(suffix, "")


def sniff_image_mime_type(content):
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if len(content) >= 12 and content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return "image/webp"
    return ""


def format_file_size(size):
    value = float(size or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024


def safe_filename(filename):
    name = (
        (filename or DEFAULT_FILENAME)
        .replace("\\", "/")
        .rsplit("/", 1)[-1]
        .strip()
    )
    return name or DEFAULT_FILENAME
