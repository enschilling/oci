import json
import time

import httpx


DEFAULT_TOKEN_CACHE_SECONDS = 55 * 60
EXPIRY_SKEW_SECONDS = 5 * 60


class AdbMcpAuthError(RuntimeError):
    pass


class AdbMcpTokenProvider:
    def __init__(
        self,
        region,
        database_ocid,
        username,
        password,
        timeout_seconds,
        http_client=None,
        clock=None,
    ):
        self.region = region
        self.database_ocid = database_ocid
        self.username = username
        self.password = password
        self.timeout_seconds = timeout_seconds
        self.http_client = http_client or httpx.Client(timeout=timeout_seconds)
        self.clock = clock or time.time
        self._token = ""
        self._expires_at = 0

    def authorization_headers(self, force_refresh=False):
        return {"Authorization": f"Bearer {self.token(force_refresh=force_refresh)}"}

    def token(self, force_refresh=False):
        if not force_refresh and self._token and self.clock() < self._expires_at:
            return self._token

        self._token, self._expires_at = self._fetch_token()
        return self._token

    def _fetch_token(self):
        if not self.username or not self.password:
            raise AdbMcpAuthError(
                "ADB MCP bearer token generation requires a username and password."
            )

        try:
            response = self.http_client.post(
                self._token_url(),
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
                json={
                    "grant_type": "password",
                    "username": self.username,
                    "password": self.password,
                },
                timeout=self.timeout_seconds,
            )
        except Exception as exc:
            raise AdbMcpAuthError(f"ADB MCP token request failed: {exc}") from exc

        status_code = getattr(response, "status_code", 200)
        if status_code >= 400:
            response_text = _response_text(response)
            raise AdbMcpAuthError(
                f"ADB MCP token request failed with HTTP {status_code}: "
                f"{response_text}{_token_error_hint(response_text)}"
            )

        payload = _response_json(response)
        token = payload.get("access_token") or payload.get("accessToken")
        if not isinstance(token, str) or not token.strip():
            raise AdbMcpAuthError("ADB MCP token response did not contain access_token.")

        return token.strip(), self.clock() + _cache_seconds(payload)

    def _token_url(self):
        return (
            f"https://dataaccess.adb.{self.region}.oraclecloudapps.com"
            f"/adb/auth/v1/databases/{self.database_ocid}/token"
        )


def _cache_seconds(payload):
    expires_in = _int_value(payload.get("expires_in") or payload.get("expiresIn"))
    if not expires_in:
        return DEFAULT_TOKEN_CACHE_SECONDS
    return max(1, expires_in - EXPIRY_SKEW_SECONDS)


def _int_value(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _response_json(response):
    try:
        return response.json()
    except Exception:
        pass

    try:
        return json.loads(_response_text(response))
    except json.JSONDecodeError as exc:
        raise AdbMcpAuthError(f"ADB MCP token response was not valid JSON: {exc}") from exc


def _response_text(response):
    text = getattr(response, "text", "")
    if isinstance(text, str):
        return text.strip()
    data = getattr(response, "data", "")
    if isinstance(data, (bytes, bytearray)):
        return data.decode("utf-8", errors="replace").strip()
    return str(data or "").strip()


def _token_error_hint(response_text):
    try:
        payload = json.loads(response_text)
    except json.JSONDecodeError:
        payload = {}

    code = str(payload.get("code", "")).strip()
    message = str(payload.get("message", "")).strip()
    error = str(payload.get("error", "")).strip()
    rejected_grant = (
        code == "ADB-00007"
        or message == "invalid_grant"
        or error == "invalid_grant"
    )
    if not rejected_grant:
        return ""

    return (
        " Hint: ADB MCP rejected the database password grant. Check that "
        "OCI_ADB_DATABASE_OCID and OCI_ADB_MCP_REGION point to the same "
        "database, OCI_ADB_MCP_USERNAME is a valid database user, and the "
        "Vault secret or OCI_ADB_MCP_PASSWORD contains that user's current "
        "database password. Also check whether the database user is locked "
        "or the password has expired."
    )
