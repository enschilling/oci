import json
from dataclasses import dataclass

import httpx


@dataclass
class McpSqlResult:
    columns: list
    rows: list
    truncated: bool = False


class AdbMcpError(RuntimeError):
    pass


class AdbMcpClient:
    def __init__(
        self,
        region,
        database_ocid,
        execute_tool,
        sql_argument,
        max_rows,
        timeout_seconds,
        token_provider,
        offset_argument="",
        limit_argument="",
        http_client=None,
    ):
        self.region = region
        self.database_ocid = database_ocid
        self.execute_tool = execute_tool
        self.sql_argument = sql_argument
        self.max_rows = max_rows
        self.timeout_seconds = timeout_seconds
        self.token_provider = token_provider
        self.offset_argument = offset_argument
        self.limit_argument = limit_argument
        self.http_client = http_client or httpx.Client(timeout=timeout_seconds)
        self.session_id = ""
        self.next_id = 1

    def execute_sql(self, sql):
        self._rpc(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "oci-llm-chat", "version": "1.0"},
            },
        )
        self._ensure_tool_available()
        result = self._rpc(
            "tools/call",
            {
                "name": self.execute_tool,
                "arguments": self._tool_arguments(sql),
            },
        )
        return normalize_sql_result(result, self.max_rows)

    def _tool_arguments(self, sql):
        arguments = {self.sql_argument: sql}
        if self.offset_argument:
            arguments[self.offset_argument] = 0
        if self.limit_argument:
            arguments[self.limit_argument] = self.max_rows
        return arguments

    def _ensure_tool_available(self):
        result = self._rpc("tools/list", {})
        tools = result.get("tools")
        if not isinstance(tools, list):
            return

        tool_names = _tool_names(tools)
        if self.execute_tool in tool_names:
            return

        available = ", ".join(tool_names) if tool_names else "none"
        raise AdbMcpError(
            f"ADB MCP tool {self.execute_tool!r} is not available for the "
            f"authenticated database user. Available tools: {available}. "
            "Create or grant a Select AI Agent tool for this user, or update "
            "OCI_ADB_MCP_EXECUTE_TOOL to an available tool name."
        )

    def _rpc(self, method, params):
        request_id = str(self.next_id)
        self.next_id += 1
        body = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params,
        }
        response = self._post(body)
        if _status_code(response) == 401:
            response = self._post(body, force_refresh=True)
            if _status_code(response) == 401:
                raise AdbMcpError(
                    "ADB MCP request failed with HTTP 401 Unauthorized after "
                    "refreshing the bearer token."
                )

        _raise_for_status(response)
        self._capture_session_id(response)
        payload = decode_mcp_response(_response_data(response), request_id)
        if payload.get("error"):
            raise AdbMcpError(str(payload["error"]))
        return payload.get("result", {})

    def _post(self, body, force_refresh=False):
        return self.http_client.post(
            self._endpoint(),
            headers=self._headers(force_refresh=force_refresh),
            json=body,
            timeout=self.timeout_seconds,
        )

    def _headers(self, force_refresh=False):
        headers = {
            "content-type": "application/json",
            "accept": "application/json, text/event-stream",
        }
        headers.update(
            self.token_provider.authorization_headers(force_refresh=force_refresh)
        )
        if self.session_id:
            headers["mcp-session-id"] = self.session_id
        return headers

    def _capture_session_id(self, response):
        headers = getattr(response, "headers", {}) or {}
        self.session_id = (
            headers.get("mcp-session-id")
            or headers.get("Mcp-Session-Id")
            or self.session_id
        )

    def _endpoint(self):
        return (
            f"https://dataaccess.adb.{self.region}.oraclecloudapps.com"
            f"/adb/mcp/v1/databases/{self.database_ocid}"
        )


def decode_mcp_response(data, request_id=None):
    if isinstance(data, (bytes, bytearray)):
        data = data.decode("utf-8")
    if not isinstance(data, str):
        return data

    stripped = data.strip()
    if not stripped:
        return {}

    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass

    payloads = []
    for line in stripped.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        event_data = line.removeprefix("data:").strip()
        if event_data == "[DONE]":
            continue
        try:
            payloads.append(json.loads(event_data))
        except json.JSONDecodeError:
            continue

    if not payloads:
        raise AdbMcpError("ADB MCP response was not valid JSON.")

    if request_id is not None:
        for payload in payloads:
            if str(payload.get("id")) == str(request_id):
                return payload
    return payloads[-1]


def _status_code(response):
    return getattr(response, "status_code", 200)


def _raise_for_status(response):
    status_code = _status_code(response)
    if status_code >= 400:
        raise AdbMcpError(
            f"ADB MCP request failed with HTTP {status_code}: {_response_text(response)}"
        )


def _response_data(response):
    data = getattr(response, "data", None)
    if data is not None:
        return data
    return _response_text(response)


def _response_text(response):
    text = getattr(response, "text", "")
    if isinstance(text, str):
        return text.strip()
    data = getattr(response, "data", "")
    if isinstance(data, (bytes, bytearray)):
        return data.decode("utf-8", errors="replace").strip()
    return str(data or "").strip()


def _tool_names(tools):
    names = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        name = tool.get("name")
        if name:
            names.append(str(name))
    return names


def normalize_sql_result(result, max_rows):
    if result.get("isError"):
        raise AdbMcpError(_content_text(result) or "ADB MCP tool returned an error.")

    payload = _structured_payload(result)
    columns, rows = _columns_and_rows(payload)
    truncated = False
    if max_rows and max_rows > 0 and len(rows) > max_rows:
        rows = rows[:max_rows]
        truncated = True

    return McpSqlResult(columns=columns, rows=rows, truncated=truncated)


def _structured_payload(result):
    text = _content_text(result)
    if text:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"columns": ["result"], "rows": [{"result": text}]}
    return result


def _content_text(result):
    content = result.get("content")
    if not isinstance(content, list):
        return ""
    texts = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text":
            texts.append(str(item.get("text", "")))
    return "\n".join(text for text in texts if text).strip()


def _columns_and_rows(payload):
    if isinstance(payload, list):
        rows = payload
        columns = []
    elif isinstance(payload, dict):
        rows = (
            payload.get("rows")
            or payload.get("data")
            or payload.get("items")
            or payload.get("results")
            or []
        )
        columns = payload.get("columns") or []
    else:
        rows = [{"result": payload}]
        columns = ["result"]

    rows = _normalize_rows(rows, columns)
    columns = _normalize_columns(columns, rows)
    return columns, rows


def _normalize_rows(rows, columns):
    if not isinstance(rows, list):
        rows = [rows]
    normalized = []
    names = _column_names(columns)
    for row in rows:
        if isinstance(row, dict):
            normalized.append(row)
        elif isinstance(row, (list, tuple)):
            if names:
                normalized.append({name: value for name, value in zip(names, row)})
            else:
                normalized.append({f"column_{index + 1}": value for index, value in enumerate(row)})
        else:
            normalized.append({"result": row})
    return normalized


def _normalize_columns(columns, rows):
    names = _column_names(columns)
    if names:
        return names
    seen = []
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.append(key)
    return seen


def _column_names(columns):
    if not isinstance(columns, list):
        return []
    names = []
    for column in columns:
        if isinstance(column, dict):
            name = column.get("name") or column.get("columnName") or column.get("label")
        else:
            name = column
        if name:
            names.append(str(name))
    return names
