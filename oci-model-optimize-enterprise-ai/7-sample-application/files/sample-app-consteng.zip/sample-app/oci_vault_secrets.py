import base64

import oci


class VaultSecretError(RuntimeError):
    pass


def read_secret_value(secret_ocid, auth, timeout_seconds=30, client=None):
    if not secret_ocid:
        raise VaultSecretError("A Vault secret OCID is required.")

    secrets_client = client or oci.secrets.SecretsClient(
        auth.config,
        signer=auth.signer,
        retry_strategy=None,
        timeout=timeout_seconds,
    )
    try:
        response = secrets_client.get_secret_bundle(secret_ocid, stage="CURRENT")
    except Exception as exc:
        raise VaultSecretError(f"Unable to read Vault secret {secret_ocid!r}: {exc}") from exc

    content = _secret_content(response)
    if not content:
        raise VaultSecretError("Vault secret bundle did not contain secret content.")

    try:
        return base64.b64decode(content).decode("utf-8").strip()
    except Exception as exc:
        raise VaultSecretError("Vault secret content was not valid base64 text.") from exc


def _secret_content(response):
    bundle = getattr(response, "data", None)
    bundle_content = getattr(bundle, "secret_bundle_content", None)
    return getattr(bundle_content, "content", "")
