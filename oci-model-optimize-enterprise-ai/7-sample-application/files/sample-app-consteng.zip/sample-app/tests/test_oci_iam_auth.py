import unittest
from pathlib import Path
from unittest.mock import patch

from oci_iam_auth import make_iam_auth


class OciIamAuthTests(unittest.TestCase):
    def test_make_iam_auth_uses_config_file_profile_and_region(self):
        config = {
            "tenancy": "tenancy-ocid",
            "user": "user-ocid",
            "fingerprint": "fingerprint",
            "key_file": "~/keys/oci_api_key.pem",
            "region": "us-phoenix-1",
        }
        signer = object()
        with patch("oci_iam_auth.oci.config.from_file", return_value=config), patch(
            "oci_iam_auth.oci.config.validate_config",
        ) as validate_config, patch(
            "oci_iam_auth.oci.signer.Signer",
            return_value=signer,
        ) as signer_cls:
            auth = make_iam_auth(
                "~/.oci/config",
                "WORKSHOP",
                "us-ashburn-1",
            )

        signer_cls.assert_called_once_with(
            tenancy="tenancy-ocid",
            user="user-ocid",
            fingerprint="fingerprint",
            private_key_file_location=str(Path("~/keys/oci_api_key.pem").expanduser()),
            pass_phrase=None,
            private_key_content=None,
        )
        validate_config.assert_called_once_with(config)
        self.assertEqual(auth.config["region"], "us-ashburn-1")
        self.assertEqual(auth.signer, signer)

    def test_make_iam_auth_uses_resource_principal(self):
        signer = object()
        with patch(
            "oci_iam_auth.oci.auth.signers.get_resource_principals_signer",
            return_value=signer,
        ) as signer_factory, patch("oci_iam_auth.oci.config.from_file") as from_file:
            auth = make_iam_auth(region="us-ashburn-1", auth_mode="resource_principal")

        signer_factory.assert_called_once_with()
        from_file.assert_not_called()
        self.assertEqual(auth.config, {"region": "us-ashburn-1"})
        self.assertEqual(auth.signer, signer)


if __name__ == "__main__":
    unittest.main()
