import base64
import unittest

import prompt_images


PNG_BYTES = b"\x89PNG\r\n\x1a\npng-data"
JPEG_BYTES = b"\xff\xd8\xffjpeg-data"
WEBP_BYTES = b"RIFF\x00\x00\x00\x00WEBPwebp-data"


class FakeUploadedFile:
    def __init__(self, name="folder/photo.png", mime_type="image/png", content=PNG_BYTES):
        self.name = name
        self.type = mime_type
        self._content = content

    def getvalue(self):
        return self._content


class PromptImageTests(unittest.TestCase):
    def test_capture_uploaded_image_returns_metadata_and_data_url(self):
        image = prompt_images.capture_uploaded_image(FakeUploadedFile())

        self.assertEqual(image.filename, "photo.png")
        self.assertEqual(image.mime_type, "image/png")
        self.assertEqual(image.size, len(PNG_BYTES))
        self.assertEqual(
            image.data_url,
            "data:image/png;base64," + base64.b64encode(PNG_BYTES).decode("ascii"),
        )
        self.assertEqual(
            image.display_ref(),
            {
                "filename": "photo.png",
                "mime_type": "image/png",
                "size": len(PNG_BYTES),
            },
        )
        self.assertEqual(image.as_dict()["data_url"], image.data_url)

    def test_capture_uploaded_image_allows_jpeg_and_webp(self):
        jpeg = prompt_images.capture_uploaded_image(
            FakeUploadedFile("photo.jpeg", "image/jpeg", JPEG_BYTES)
        )
        webp = prompt_images.capture_uploaded_image(
            FakeUploadedFile("photo.webp", "image/webp", WEBP_BYTES)
        )

        self.assertEqual(jpeg.mime_type, "image/jpeg")
        self.assertEqual(webp.mime_type, "image/webp")

    def test_capture_uploaded_image_rejects_empty_file(self):
        with self.assertRaisesRegex(prompt_images.PromptImageError, "empty"):
            prompt_images.capture_uploaded_image(
                FakeUploadedFile("photo.png", "image/png", b"")
            )

    def test_capture_uploaded_image_rejects_oversized_file(self):
        content = PNG_BYTES + b"x" * (prompt_images.MAX_IMAGE_BYTES + 1)

        with self.assertRaisesRegex(prompt_images.PromptImageError, "too large"):
            prompt_images.capture_uploaded_image(
                FakeUploadedFile("photo.png", "image/png", content)
            )

    def test_capture_uploaded_image_rejects_unsupported_extension(self):
        with self.assertRaisesRegex(prompt_images.PromptImageError, "Unsupported"):
            prompt_images.capture_uploaded_image(
                FakeUploadedFile("photo.gif", "image/gif", b"GIF89a")
            )

    def test_capture_uploaded_image_rejects_mime_mismatch(self):
        with self.assertRaisesRegex(prompt_images.PromptImageError, "MIME type"):
            prompt_images.capture_uploaded_image(
                FakeUploadedFile("photo.png", "image/jpeg", PNG_BYTES)
            )

    def test_capture_uploaded_image_rejects_extension_mismatch(self):
        with self.assertRaisesRegex(prompt_images.PromptImageError, "extension"):
            prompt_images.capture_uploaded_image(
                FakeUploadedFile("photo.jpg", "image/png", PNG_BYTES)
            )

    def test_safe_filename_removes_path_components(self):
        self.assertEqual(prompt_images.safe_filename("../folder/photo.png"), "photo.png")


if __name__ == "__main__":
    unittest.main()
