import unittest
from unittest.mock import patch

import app


class AppConfigurationTests(unittest.TestCase):
    def test_prompt_value_populates_text_only_composer(self):
        self.assertEqual(
            app.prompt_value("Use this prompt"),
            {"text": "Use this prompt", "files": []},
        )

    @patch("app.settings")
    def test_configured_settings_applies_runtime_toggles(self, mock_settings):
        mock_settings.return_value = {
            "vector_store_ids": ["ocid1.generativeaivectorstore.example"],
        }

        result = app.configured_settings(False, True, False, True, "AUS-BANK-02")

        self.assertFalse(result["model_routing_enabled"])
        self.assertTrue(result["prompt_protection_enabled"])
        self.assertTrue(result["governed_data_enabled"])
        self.assertEqual(result["project_code"], "AUS-BANK-02")
        self.assertEqual(result["vector_store_ids"], [])

    def test_runtime_status_escapes_dynamic_values(self):
        status = app.runtime_status(
            True,
            False,
            True,
            True,
            "<project>",
            "<model>",
            "<ready>",
        )

        self.assertIn("&lt;project&gt;", status)
        self.assertIn("&lt;model&gt;", status)
        self.assertIn("&lt;ready&gt;", status)
        self.assertNotIn("<project>", status)


if __name__ == "__main__":
    unittest.main()
