import unittest

from sql_guardrails import (
    SqlGuardrailError,
    validate_project_scope,
    validate_read_only_sql,
)


class SqlGuardrailTests(unittest.TestCase):
    def test_allows_select_and_strips_trailing_semicolon(self):
        self.assertEqual(validate_read_only_sql(" select * from SEER_GOLD_PROJECT_CONTEXT; "), "select * from SEER_GOLD_PROJECT_CONTEXT")

    def test_allows_with_query(self):
        sql = "WITH latest AS (SELECT * FROM SEER_GOLD_PROJECT_CONTEXT) SELECT * FROM latest"

        self.assertEqual(validate_read_only_sql(sql), sql)

    def test_rejects_write_keyword(self):
        with self.assertRaises(SqlGuardrailError):
            validate_read_only_sql("DELETE FROM SEER_GOLD_PROJECT_CONTEXT")

    def test_rejects_multiple_statements(self):
        with self.assertRaises(SqlGuardrailError):
            validate_read_only_sql("SELECT * FROM SEER_GOLD_PROJECT_CONTEXT; SELECT * FROM SEER_GOLD_SUPPLIER_PROFILE")

    def test_project_scope_allows_matching_project_code_filter(self):
        sql = "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT WHERE project_code = 'AUS-BANK-01'"

        self.assertEqual(validate_project_scope(sql, "AUS-BANK-01"), sql)

    def test_project_scope_allows_reversed_project_code_filter(self):
        sql = "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT WHERE 'AUS-BANK-01' = PROJECT_CODE"

        self.assertEqual(validate_project_scope(sql, "AUS-BANK-01"), sql)

    def test_project_scope_allows_qualified_upper_filter(self):
        sql = (
            "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT r "
            "WHERE UPPER(r.PROJECT_CODE) = UPPER('AUS-BANK-01')"
        )

        self.assertEqual(validate_project_scope(sql, "AUS-BANK-01"), sql)

    def test_project_scope_rejects_qualified_upper_filter_for_other_project(self):
        sql = (
            "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT r "
            "WHERE UPPER(r.PROJECT_CODE) = UPPER('HARBOR-SEIS-01')"
        )

        with self.assertRaises(SqlGuardrailError):
            validate_project_scope(sql, "AUS-BANK-01")

    def test_project_scope_rejects_missing_project_code_filter(self):
        with self.assertRaises(SqlGuardrailError):
            validate_project_scope("SELECT * FROM SEER_GOLD_PROJECT_CONTEXT", "AUS-BANK-01")

    def test_project_scope_rejects_different_project_code_filter(self):
        with self.assertRaises(SqlGuardrailError):
            validate_project_scope("SELECT * FROM SEER_GOLD_PROJECT_CONTEXT WHERE project_code = 'HARBOR-SEIS-01'", "AUS-BANK-01")

    def test_project_scope_rejects_or_that_can_widen_results(self):
        with self.assertRaises(SqlGuardrailError):
            validate_project_scope(
                "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT WHERE project_code = 'AUS-BANK-01' OR project_code = 'HARBOR-SEIS-01'",
                "AUS-BANK-01",
            )

    def test_project_scope_rejects_union_that_can_widen_results(self):
        with self.assertRaises(SqlGuardrailError):
            validate_project_scope(
                "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT WHERE project_code = 'AUS-BANK-01' "
                "UNION SELECT * FROM SEER_GOLD_PROJECT_CONTEXT",
                "AUS-BANK-01",
            )


if __name__ == "__main__":
    unittest.main()
