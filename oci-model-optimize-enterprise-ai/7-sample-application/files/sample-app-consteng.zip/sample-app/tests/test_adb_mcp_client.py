import json
import unittest
from types import SimpleNamespace

from adb_mcp_client import AdbMcpClient, AdbMcpError, decode_mcp_response


class FakeHttpClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def post(self, url, headers=None, json=None, timeout=None):
        self.calls.append(
            {
                "url": url,
                "headers": headers or {},
                "json": json,
                "timeout": timeout,
            }
        )
        return self.responses.pop(0)


class FakeTokenProvider:
    def __init__(self, token="token"):
        self.token = token
        self.calls = []

    def authorization_headers(self, force_refresh=False):
        self.calls.append(force_refresh)
        if force_refresh:
            self.token = "refreshed-token"
        return {"Authorization": f"Bearer {self.token}"}


class FailingRefreshTokenProvider(FakeTokenProvider):
    def authorization_headers(self, force_refresh=False):
        if force_refresh:
            raise RuntimeError("refresh failed")
        return super().authorization_headers(force_refresh=force_refresh)


def response(payload, headers=None, status_code=200):
    text = json.dumps(payload)
    return SimpleNamespace(
        data=text,
        text=text,
        headers=headers or {},
        status_code=status_code,
    )


class AdbMcpClientTests(unittest.TestCase):
    def test_execute_sql_initializes_and_calls_configured_tool(self):
        tool_payload = {
            "columns": ["id", "name"],
            "rows": [[1, "A"], [2, "B"]],
        }
        fake_client = FakeHttpClient(
            [
                response(
                    {"jsonrpc": "2.0", "id": "1", "result": {}},
                    headers={"mcp-session-id": "session-id"},
                ),
                response(
                    {
                        "jsonrpc": "2.0",
                        "id": "2",
                        "result": {"tools": [{"name": "execute_sql"}]},
                    }
                ),
                response(
                    {
                        "jsonrpc": "2.0",
                        "id": "3",
                        "result": {
                            "content": [
                                {"type": "text", "text": json.dumps(tool_payload)}
                            ]
                        },
                    }
                ),
            ]
        )
        client = AdbMcpClient(
            "us-ashburn-1",
            "database",
            "execute_sql",
            "statement",
            max_rows=1,
            timeout_seconds=30,
            token_provider=FakeTokenProvider(),
            offset_argument="offset",
            limit_argument="limit",
            http_client=fake_client,
        )

        result = client.execute_sql("SELECT * FROM SEER_GOLD_PROJECT_CONTEXT")

        self.assertEqual(fake_client.calls[0]["json"]["method"], "initialize")
        self.assertEqual(fake_client.calls[0]["headers"]["Authorization"], "Bearer token")
        self.assertEqual(fake_client.calls[1]["json"]["method"], "tools/list")
        self.assertEqual(fake_client.calls[1]["headers"]["mcp-session-id"], "session-id")
        self.assertEqual(fake_client.calls[2]["json"]["method"], "tools/call")
        self.assertEqual(fake_client.calls[2]["headers"]["mcp-session-id"], "session-id")
        self.assertEqual(
            fake_client.calls[2]["json"]["params"],
            {
                "name": "execute_sql",
                "arguments": {
                    "statement": "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT",
                    "offset": 0,
                    "limit": 1,
                },
            },
        )
        self.assertEqual(result.columns, ["id", "name"])
        self.assertEqual(result.rows, [{"id": 1, "name": "A"}])
        self.assertTrue(result.truncated)

    def test_refreshes_bearer_token_once_on_401(self):
        fake_client = FakeHttpClient(
            [
                response({"error": "expired"}, status_code=401),
                response(
                    {"jsonrpc": "2.0", "id": "1", "result": {}},
                    headers={"mcp-session-id": "session-id"},
                ),
                response(
                    {
                        "jsonrpc": "2.0",
                        "id": "2",
                        "result": {"tools": [{"name": "execute_sql"}]},
                    }
                ),
                response(
                    {
                        "jsonrpc": "2.0",
                        "id": "3",
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": json.dumps({"columns": [], "rows": []}),
                                }
                            ]
                        },
                    }
                ),
            ]
        )
        token_provider = FakeTokenProvider()
        client = AdbMcpClient(
            "us-ashburn-1",
            "database",
            "execute_sql",
            "statement",
            max_rows=50,
            timeout_seconds=30,
            token_provider=token_provider,
            http_client=fake_client,
        )

        client.execute_sql("SELECT 1 FROM dual")

        self.assertEqual(token_provider.calls, [False, True, False, False])
        self.assertEqual(fake_client.calls[0]["headers"]["Authorization"], "Bearer token")
        self.assertEqual(
            fake_client.calls[1]["headers"]["Authorization"],
            "Bearer refreshed-token",
        )

    def test_execute_sql_fails_clearly_when_tool_is_unavailable(self):
        fake_client = FakeHttpClient(
            [
                response({"jsonrpc": "2.0", "id": "1", "result": {}}),
                response({"jsonrpc": "2.0", "id": "2", "result": {"tools": []}}),
            ]
        )
        client = AdbMcpClient(
            "us-ashburn-1",
            "database",
            "execute_sql",
            "statement",
            max_rows=50,
            timeout_seconds=30,
            token_provider=FakeTokenProvider(),
            http_client=fake_client,
        )

        with self.assertRaisesRegex(AdbMcpError, "not available"):
            client.execute_sql("SELECT 1 FROM dual")

        self.assertEqual(len(fake_client.calls), 2)

    def test_second_401_fails_after_single_refresh(self):
        fake_client = FakeHttpClient(
            [
                response({"error": "expired"}, status_code=401),
                response({"error": "expired"}, status_code=401),
            ]
        )
        client = AdbMcpClient(
            "us-ashburn-1",
            "database",
            "execute_sql",
            "statement",
            max_rows=50,
            timeout_seconds=30,
            token_provider=FakeTokenProvider(),
            http_client=fake_client,
        )

        with self.assertRaises(AdbMcpError):
            client._rpc("initialize", {})

        self.assertEqual(len(fake_client.calls), 2)

    def test_token_refresh_failure_fails_without_second_request(self):
        fake_client = FakeHttpClient([response({"error": "expired"}, status_code=401)])
        client = AdbMcpClient(
            "us-ashburn-1",
            "database",
            "execute_sql",
            "statement",
            max_rows=50,
            timeout_seconds=30,
            token_provider=FailingRefreshTokenProvider(),
            http_client=fake_client,
        )

        with self.assertRaises(RuntimeError):
            client._rpc("initialize", {})

        self.assertEqual(len(fake_client.calls), 1)

    def test_decode_mcp_response_reads_sse_data(self):
        payload = decode_mcp_response(
            'event: message\ndata: {"jsonrpc":"2.0","id":"3","result":{"ok":true}}\n',
            request_id="3",
        )

        self.assertEqual(payload["result"], {"ok": True})


if __name__ == "__main__":
    unittest.main()
