import json
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from oci.exceptions import ServiceError
from nl2sql_client import Nl2SqlClient, extract_generated_sql


class FakeClient:
    def __init__(self, data):
        self.data = data
        self.calls = []

    def call_api(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            data=json.dumps(self.data),
            headers={"opc-request-id": "request-id"},
        )


class Nl2SqlClientTests(unittest.TestCase):
    def test_generate_sql_posts_expected_path_and_body(self):
        fake_client = FakeClient({"jobOutput": {"content": "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT"}})
        client = Nl2SqlClient(
            "us-chicago-1",
            "20260325",
            "semantic-store",
            auth=None,
            client=fake_client,
        )

        result = client.generate_sql("show the Austin project context")

        self.assertEqual(result.status, "ok")
        self.assertEqual(result.sql, "SELECT * FROM SEER_GOLD_PROJECT_CONTEXT")
        self.assertEqual(result.request_id, "request-id")
        call = fake_client.calls[0]
        self.assertEqual(
            call["resource_path"],
            "/20260325/semanticStores/semantic-store/actions/generateSqlFromNl",
        )
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["body"]["inputNaturalLanguageQuery"], "show the Austin project context")

    def test_generate_sql_returns_not_answerable_without_sql(self):
        client = Nl2SqlClient("region", "version", "store", auth=None, client=FakeClient({}))

        result = client.generate_sql("question")

        self.assertEqual(result.status, "not_answerable")
        self.assertEqual(result.sql, "")

    def test_generate_sql_retries_throttled_request(self):
        client_api = Mock()
        client_api.call_api.side_effect = [
            ServiceError(429, None, {}, "Request limit exceeded"),
            SimpleNamespace(
                data=json.dumps({"jobOutput": {"content": "SELECT 1 FROM dual"}}),
                headers={"opc-request-id": "request-id"},
            ),
        ]
        client = Nl2SqlClient("region", "version", "store", auth=None, client=client_api)

        with patch("nl2sql_client.time.sleep") as sleep:
            result = client.generate_sql("show project context")

        self.assertEqual(result.status, "ok")
        self.assertEqual(client_api.call_api.call_count, 2)
        sleep.assert_called_once_with(2)

    def test_extract_generated_sql_from_job_output_content(self):
        data = {
            "jobOutput": {
                "jobOutputLocation": "INLINE",
                "content": "SELECT 1 FROM dual",
            }
        }

        self.assertEqual(extract_generated_sql(data), "SELECT 1 FROM dual")


if __name__ == "__main__":
    unittest.main()
