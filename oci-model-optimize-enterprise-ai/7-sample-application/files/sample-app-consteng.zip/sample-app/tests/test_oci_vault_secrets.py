import base64
import unittest
from types import SimpleNamespace

from oci_vault_secrets import VaultSecretError, read_secret_value


class FakeSecretsClient:
    def __init__(self, response):
        self.response = response
        self.calls = []

    def get_secret_bundle(self, secret_ocid, stage=None):
        self.calls.append({"secret_ocid": secret_ocid, "stage": stage})
        return self.response


def secret_response(value):
    encoded = base64.b64encode(value.encode("utf-8")).decode("ascii")
    return SimpleNamespace(
        data=SimpleNamespace(
            secret_bundle_content=SimpleNamespace(content=encoded)
        )
    )


class VaultSecretsTests(unittest.TestCase):
    def test_reads_current_secret_bundle_value(self):
        client = FakeSecretsClient(secret_response("database-password\n"))

        value = read_secret_value(
            "ocid1.vaultsecret.example",
            auth=SimpleNamespace(config={}, signer="signer"),
            client=client,
        )

        self.assertEqual(value, "database-password")
        self.assertEqual(
            client.calls,
            [{"secret_ocid": "ocid1.vaultsecret.example", "stage": "CURRENT"}],
        )

    def test_missing_secret_content_fails(self):
        client = FakeSecretsClient(SimpleNamespace(data=SimpleNamespace()))

        with self.assertRaises(VaultSecretError):
            read_secret_value(
                "ocid1.vaultsecret.example",
                auth=SimpleNamespace(config={}, signer="signer"),
                client=client,
            )


if __name__ == "__main__":
    unittest.main()
