import json
import unittest
from types import SimpleNamespace

from adb_mcp_auth import AdbMcpAuthError, AdbMcpTokenProvider


class FakeHttpClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def post(self, url, headers=None, json=None, timeout=None):
        self.calls.append(
            {
                "url": url,
                "headers": headers or {},
                "json": json,
                "timeout": timeout,
            }
        )
        return self.responses.pop(0)


def response(payload, status_code=200):
    return SimpleNamespace(
        status_code=status_code,
        text=json.dumps(payload),
        json=lambda: payload,
    )


class MutableClock:
    def __init__(self, value):
        self.value = value

    def __call__(self):
        return self.value


class AdbMcpTokenProviderTests(unittest.TestCase):
    def test_generates_and_caches_authorization_header(self):
        http_client = FakeHttpClient(
            [
                response({"access_token": "token-one", "expires_in": 3600}),
                response({"access_token": "token-two", "expires_in": 3600}),
            ]
        )
        clock = MutableClock(1000)
        provider = AdbMcpTokenProvider(
            "us-ashburn-1",
            "database",
            "user",
            "password",
            timeout_seconds=30,
            http_client=http_client,
            clock=clock,
        )

        self.assertEqual(
            provider.authorization_headers(),
            {"Authorization": "Bearer token-one"},
        )
        self.assertEqual(
            provider.authorization_headers(),
            {"Authorization": "Bearer token-one"},
        )
        clock.value = 4400
        self.assertEqual(
            provider.authorization_headers(),
            {"Authorization": "Bearer token-two"},
        )

        self.assertEqual(len(http_client.calls), 2)
        self.assertEqual(
            http_client.calls[0]["url"],
            (
                "https://dataaccess.adb.us-ashburn-1.oraclecloudapps.com"
                "/adb/auth/v1/databases/database/token"
            ),
        )
        self.assertEqual(
            http_client.calls[0]["json"],
            {
                "grant_type": "password",
                "username": "user",
                "password": "password",
            },
        )

    def test_force_refresh_bypasses_cached_token(self):
        http_client = FakeHttpClient(
            [
                response({"access_token": "token-one"}),
                response({"access_token": "token-two"}),
            ]
        )
        provider = AdbMcpTokenProvider(
            "us-ashburn-1",
            "database",
            "user",
            "password",
            timeout_seconds=30,
            http_client=http_client,
        )

        self.assertEqual(provider.token(), "token-one")
        self.assertEqual(provider.token(force_refresh=True), "token-two")
        self.assertEqual(len(http_client.calls), 2)

    def test_invalid_grant_error_includes_actionable_hint(self):
        http_client = FakeHttpClient(
            [
                response(
                    {
                        "code": "ADB-00007",
                        "status": "FAILURE",
                        "message": "invalid_grant",
                        "error": "invalid_grant",
                    },
                    status_code=400,
                )
            ]
        )
        provider = AdbMcpTokenProvider(
            "us-ashburn-1",
            "database",
            "user",
            "password",
            timeout_seconds=30,
            http_client=http_client,
        )

        with self.assertRaisesRegex(AdbMcpAuthError, "Vault secret"):
            provider.authorization_headers()

    def test_missing_credentials_fail_before_token_request(self):
        http_client = FakeHttpClient([])
        provider = AdbMcpTokenProvider(
            "us-ashburn-1",
            "database",
            "",
            "",
            timeout_seconds=30,
            http_client=http_client,
        )

        with self.assertRaises(AdbMcpAuthError):
            provider.authorization_headers()

        self.assertEqual(http_client.calls, [])

if __name__ == "__main__":
    unittest.main()
