import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import preflight


class PreflightTests(unittest.TestCase):
    def complete_environment(self):
        values = {name: "configured" for name in preflight.REQUIRED_VALUES}
        values["OCI_AUTH_MODE"] = "resource_principal"
        values["OCI_RESOURCE_PRINCIPAL_VERSION"] = "2.2"
        return values

    def test_resource_principal_environment_passes(self):
        with patch.dict(os.environ, self.complete_environment(), clear=True):
            self.assertEqual(preflight.validate_environment(), [])

    def test_missing_resource_value_is_reported(self):
        values = self.complete_environment()
        values.pop("OCI_GENAI_VECTOR_STORE_IDS")
        with patch.dict(os.environ, values, clear=True):
            errors = preflight.validate_environment()
        self.assertIn("missing OCI_GENAI_VECTOR_STORE_IDS", errors)

    def test_config_file_mode_requires_existing_config(self):
        values = self.complete_environment()
        values["OCI_AUTH_MODE"] = "config_file"
        values.pop("OCI_RESOURCE_PRINCIPAL_VERSION")
        with tempfile.TemporaryDirectory() as directory:
            config_file = Path(directory) / "config"
            config_file.write_text("[DEFAULT]", encoding="utf-8")
            values["OCI_CONFIG_FILE"] = str(config_file)
            with patch.dict(os.environ, values, clear=True):
                self.assertEqual(preflight.validate_environment(), [])


if __name__ == "__main__":
    unittest.main()
