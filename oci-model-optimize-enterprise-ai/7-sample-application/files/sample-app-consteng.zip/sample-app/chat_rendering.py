import re
from html import escape
from pathlib import Path

from markdown_it import MarkdownIt
import streamlit as st

from prompt_images import format_file_size


APP_DIR = Path(__file__).parent
CHAT_CSS = (APP_DIR / "chat.css").read_text(encoding="utf-8")
EXCESS_BLANK_LINES_RE = re.compile(r"\n{3,}")
MARKDOWN = (
    MarkdownIt("commonmark", {"breaks": True, "html": False})
    .enable("table")
    .enable("strikethrough")
)


def render_chat(messages, thinking=False):
    rows = []
    last_index = len(messages) - 1
    for index, message in enumerate(messages):
        role = message["role"]
        text = render_message_text(message["content"])
        if thinking and index == last_index and role == "assistant":
            text = append_loading_indicator(text)
        attachments = render_message_images(message.get("images"))
        rows.append(
            f'<div class="row {role}"><div class="bubble">'
            f"{text}{attachments}</div></div>"
        )

    # CSS column-reverse keeps a remounted Streamlit chat container anchored to
    # the visual bottom, so render newest DOM rows first while preserving visual
    # chronological order.
    chat_html = (
        f'<style>{CHAT_CSS}</style>'
        f'<div id="chat" class="chat">{"".join(reversed(rows))}</div>'
    )
    if hasattr(st, "html"):
        st.html(chat_html)
    else:
        st.markdown(chat_html, unsafe_allow_html=True)


def render_message_text(content):
    text = content.replace("\r\n", "\n").replace("\r", "\n")
    text = EXCESS_BLANK_LINES_RE.sub("\n\n", text)
    return MARKDOWN.render(text).strip()


def append_loading_indicator(html):
    indicator = (
        '<span class="loading-indicator">'
        '<span class="dot"></span><span class="dot"></span><span class="dot"></span>'
        "</span>"
    )
    if html.endswith("</p>"):
        return html[:-4] + indicator + "</p>"
    return html + indicator


def render_message_images(images):
    if not images:
        return ""

    items = []
    for image_ref in images:
        filename = escape(str(image_ref.get("filename") or "Attached image"))
        image_url = str(image_ref.get("data_url") or "")
        image_src = escape(image_url, quote=True)
        size = image_ref.get("size")
        size_label = escape(format_file_size(size)) if size is not None else ""
        size_html = (
            f'<span class="image-attachment-size">{size_label}</span>' if size_label else ""
        )
        preview_html = (
            f'<img class="image-preview" src="{image_src}" alt="{filename}">'
            if image_src
            else ""
        )
        items.append(
            '<div class="image-attachment">'
            f"{preview_html}"
            '<div class="image-attachment-meta">'
            f'<span class="image-attachment-name">{filename}</span>'
            f"{size_html}</div>"
            "</div>"
        )

    return f'<div class="image-attachments">{"".join(items)}</div>'
