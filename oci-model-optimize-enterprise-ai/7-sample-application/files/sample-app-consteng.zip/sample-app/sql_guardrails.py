import re


class SqlGuardrailError(ValueError):
    pass


BLOCKED_KEYWORDS_RE = re.compile(
    r"\b(insert|update|delete|merge|drop|alter|create|truncate|grant|revoke|begin|declare|execute)\b",
    re.IGNORECASE,
)
READ_ONLY_START_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE)
PROJECT_CODE_FILTER_RE = re.compile(
    r"\bproject_code\b\s*=\s*'([A-Za-z0-9_-]+)'"
    r"|'([A-Za-z0-9_-]+)'\s*=\s*\bproject_code\b",
    re.IGNORECASE,
)
PROJECT_SCOPE_BLOCKED_RE = re.compile(r"\b(or|union|minus|intersect)\b", re.IGNORECASE)


def validate_read_only_sql(sql):
    normalized = (sql or "").strip()
    if not normalized:
        raise SqlGuardrailError("Generated SQL was empty.")

    if normalized.endswith(";"):
        normalized = normalized[:-1].strip()

    if ";" in normalized:
        raise SqlGuardrailError("Generated SQL contains multiple statements.")

    if not READ_ONLY_START_RE.search(normalized):
        raise SqlGuardrailError("Generated SQL must start with SELECT or WITH.")

    blocked = BLOCKED_KEYWORDS_RE.search(normalized)
    if blocked:
        raise SqlGuardrailError(
            f"Generated SQL contains a blocked keyword: {blocked.group(1).lower()}."
        )

    return normalized


def validate_project_scope(sql, project_code):
    expected = normalized_project_code(project_code)
    if not expected:
        return sql

    blocked = PROJECT_SCOPE_BLOCKED_RE.search(sql)
    if blocked:
        raise SqlGuardrailError(
            f"Generated SQL contains {blocked.group(1).upper()}, which is not "
            "allowed with project scoping."
        )

    found_scope = False
    for match in PROJECT_CODE_FILTER_RE.finditer(sql):
        matched_ids = [value for value in match.groups() if value is not None]
        if not any(normalized_project_code(value) == expected for value in matched_ids):
            raise SqlGuardrailError(
                f"Generated SQL must not filter to a project_code other than {expected}."
            )
        found_scope = True

    if found_scope:
        return sql

    raise SqlGuardrailError(
        f"Generated SQL must filter results to project_code = '{expected}'."
    )


def normalized_project_code(project_code):
    raw = "" if project_code is None else str(project_code).strip()
    if not raw:
        return ""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", raw):
        raise SqlGuardrailError("Project code contains unsupported characters.")
    return raw.upper()
