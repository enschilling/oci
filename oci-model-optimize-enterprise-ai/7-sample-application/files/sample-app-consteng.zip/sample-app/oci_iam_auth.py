from dataclasses import dataclass
from pathlib import Path

import oci


class IamAuthError(RuntimeError):
    pass


@dataclass
class OciIamAuth:
    config: dict
    signer: object


DEFAULT_OCI_CONFIG_FILE = "~/.oci/config"
DEFAULT_OCI_CONFIG_PROFILE = "DEFAULT"
DEFAULT_OCI_AUTH_MODE = "config_file"


def make_iam_auth(
    config_file=DEFAULT_OCI_CONFIG_FILE,
    profile_name=DEFAULT_OCI_CONFIG_PROFILE,
    region="",
    auth_mode=DEFAULT_OCI_AUTH_MODE,
):
    normalized_auth_mode = (auth_mode or DEFAULT_OCI_AUTH_MODE).strip().lower().replace("-", "_")
    if normalized_auth_mode == "resource_principal":
        try:
            signer = oci.auth.signers.get_resource_principals_signer()
        except Exception as exc:
            raise IamAuthError(f"Unable to create OCI resource principal signer: {exc}") from exc
        return OciIamAuth({"region": region} if region else {}, signer)

    if normalized_auth_mode != "config_file":
        raise IamAuthError(
            "OCI_AUTH_MODE must be 'config_file' or 'resource_principal'."
        )

    try:
        config = oci.config.from_file(_expanded(config_file), profile_name)
        if region:
            config["region"] = region
        if config.get("key_file"):
            config["key_file"] = _expanded(config["key_file"])
        oci.config.validate_config(config)
        signer = oci.signer.Signer(
            tenancy=config["tenancy"],
            user=config["user"],
            fingerprint=config["fingerprint"],
            private_key_file_location=config.get("key_file"),
            pass_phrase=oci.config.get_config_value_or_default(config, "pass_phrase"),
            private_key_content=config.get("key_content"),
        )
    except Exception as exc:
        raise IamAuthError(
            f"Unable to create OCI API key signer from profile {profile_name!r}: {exc}"
        ) from exc

    return OciIamAuth(config, signer)


def _expanded(path):
    return str(Path(path or DEFAULT_OCI_CONFIG_FILE).expanduser())
