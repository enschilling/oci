import os
from pathlib import Path


REQUIRED_VALUES = (
    "OCI_GENAI_GUARDRAILS_COMPARTMENT_OCID",
    "OCI_GENAI_PROJECT_OCID",
    "OCI_GENAI_VECTOR_STORE_IDS",
    "OCI_ADB_DATABASE_OCID",
    "OCI_ADB_MCP_PASSWORD_SECRET_OCID",
    "OCI_GENAI_SEMANTIC_STORE_OCID",
    "OCI_ADB_MCP_REGION",
    "OCI_GENAI_REGION",
)


def load_environment_file(path=None):
    env_path = Path(path or Path(__file__).with_name(".env"))
    if not env_path.is_file():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, setting = line.split("=", 1)
        os.environ.setdefault(name.strip(), setting.strip())


def value(name):
    return os.getenv(name, "").strip()


def validate_environment():
    errors = [f"missing {name}" for name in REQUIRED_VALUES if not value(name)]
    auth_mode = (value("OCI_AUTH_MODE") or "config_file").lower().replace("-", "_")

    if auth_mode == "config_file":
        config_file = Path(os.path.expandvars(value("OCI_CONFIG_FILE") or "~/.oci/config")).expanduser()
        if not config_file.is_file():
            errors.append(f"OCI config file not found: {config_file}")
    elif auth_mode == "resource_principal":
        if not value("OCI_RESOURCE_PRINCIPAL_VERSION"):
            errors.append("resource principal environment is not available")
    else:
        errors.append("OCI_AUTH_MODE must be config_file or resource_principal")

    return errors


def main():
    load_environment_file()
    errors = validate_environment()
    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        raise SystemExit(1)
    print("PASS: application configuration and OCI authentication inputs are present")


if __name__ == "__main__":
    main()
