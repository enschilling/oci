import logging

from adb_mcp_auth import AdbMcpTokenProvider
from adb_mcp_client import AdbMcpClient
from nl2sql_client import Nl2SqlClient
from oci_iam_auth import make_iam_auth
from oci_vault_secrets import read_secret_value
from sql_guardrails import (
    SqlGuardrailError,
    validate_project_scope,
    validate_read_only_sql,
)


logger = logging.getLogger("oci-llm-chat")
_ADB_MCP_TOKEN_PROVIDERS = {}


def query_database(question, cfg, status_callback=None):
    missing = _missing_config(cfg)
    if missing:
        notify_status(status_callback, "SQL retrieval configuration is incomplete.")
        return {
            "status": "configuration_error",
            "message": "Missing SQL search configuration: " + ", ".join(missing),
            "columns": [],
            "rows": [],
            "truncated": False,
        }

    try:
        nl2sql_auth = make_iam_auth(
            cfg["oci_config_file"],
            cfg["oci_config_profile"],
            cfg["nl2sql_region"],
            cfg.get("oci_auth_mode"),
        )
        notify_status(status_callback, "Calling NL2SQL function...")
        nl2sql = Nl2SqlClient(
            cfg["nl2sql_region"],
            cfg["nl2sql_api_version"],
            cfg["semantic_store_ocid"],
            nl2sql_auth,
        )
        generated = nl2sql.generate_sql(
            project_scoped_question(question, cfg.get("project_code"))
        )
        logger.info(generated)
    except Exception as exc:
        logger.exception("NL2SQL generation failed")
        notify_status(status_callback, "NL2SQL function returned an error.")
        return _error_result("nl2sql_error", exc)

    if generated.status != "ok":
        notify_status(status_callback, "NL2SQL did not return a SQL query.")
        return _empty_result(generated.status)

    notify_status(status_callback, "Received SQL query from NL2SQL.")
    logger.debug(
        "Generated SQL from NL2SQL request_id=%s sql=%s",
        generated.request_id,
        generated.sql,
    )

    try:
        sql = validate_read_only_sql(generated.sql)
        sql = validate_project_scope(sql, cfg.get("project_code"))
    except SqlGuardrailError as exc:
        logger.warning("Generated SQL rejected by guardrails: %s", exc)
        notify_status(status_callback, "SQL query was rejected by guardrails.")
        return _error_result("guardrail_rejected", exc)

    try:
        notify_status(status_callback, "Calling ADB MCP server...")
        result = AdbMcpClient(
            cfg["adb_mcp_region"],
            cfg["adb_database_ocid"],
            cfg["adb_mcp_execute_tool"],
            cfg["adb_mcp_sql_argument"],
            cfg["sql_max_rows"],
            cfg["sql_timeout_seconds"],
            _adb_mcp_token_provider(cfg),
            cfg["adb_mcp_offset_argument"],
            cfg["adb_mcp_limit_argument"],
        ).execute_sql(sql)
    except Exception as exc:
        logger.exception("ADB MCP SQL execution failed")
        notify_status(status_callback, "ADB MCP server returned an error.")
        return _error_result("execution_error", exc)

    if not result.rows:
        notify_status(status_callback, "ADB MCP server returned no rows.")
        return _empty_result("no_rows", columns=result.columns, truncated=result.truncated)

    notify_status(status_callback, "Received data from ADB MCP server.")
    return {
        "status": "ok",
        "columns": result.columns,
        "rows": result.rows,
        "truncated": result.truncated,
    }


def _missing_config(cfg):
    required = {
        "semantic_store_ocid": "OCI_GENAI_SEMANTIC_STORE_OCID",
        "nl2sql_region": "OCI_GENAI_NL2SQL_REGION or OCI_GENAI_REGION",
        "nl2sql_api_version": "OCI_GENAI_NL2SQL_API_VERSION",
        "adb_mcp_region": "OCI_ADB_MCP_REGION",
        "adb_database_ocid": "OCI_ADB_DATABASE_OCID",
        "adb_mcp_username": "OCI_ADB_MCP_USERNAME",
    }
    missing = [env_name for key, env_name in required.items() if not cfg.get(key)]
    if not cfg.get("adb_mcp_password") and not cfg.get("adb_mcp_password_secret_ocid"):
        missing.append("OCI_ADB_MCP_PASSWORD_SECRET_OCID or OCI_ADB_MCP_PASSWORD")
    return missing


def project_scoped_question(question, project_code):
    if project_code in (None, ""):
        return question
    return (
        f"{question.strip()}\n\n"
        f"Current session context: the active construction project_code is '{project_code}'. "
        "Generate read-only SQL over SEER_GOLD_PROJECT_CONTEXT, SEER_GOLD_SUPPLIER_RECOMMENDATIONS, "
        "SEER_GOLD_SUPPLIER_PROFILE, SEER_GOLD_DOCUMENT_CATALOG, and SEER_GOLD_DOCUMENT_PROVENANCE. "
        f"Filter project-scoped queries to project_code = '{project_code}'. Do not return another project's records. "
        "Do not use CLOB columns in DISTINCT, GROUP BY, ORDER BY, comparisons, or LISTAGG; omit them from "
        "aggregation or project them with DBMS_LOB.SUBSTR(column_name, 4000, 1)."
    )


def _adb_mcp_token_provider(cfg):
    key = (
        cfg["adb_mcp_region"],
        cfg["adb_database_ocid"],
        cfg["adb_mcp_username"],
        cfg["sql_timeout_seconds"],
        cfg.get("adb_mcp_password_secret_ocid", ""),
        cfg.get("adb_mcp_password_secret_region", ""),
    )
    provider = _ADB_MCP_TOKEN_PROVIDERS.get(key)
    if provider and cfg.get("adb_mcp_password_secret_ocid"):
        return provider
    if provider and provider.password == cfg.get("adb_mcp_password", ""):
        return provider

    password = _adb_mcp_password(cfg)
    provider = AdbMcpTokenProvider(
        cfg["adb_mcp_region"],
        cfg["adb_database_ocid"],
        cfg["adb_mcp_username"],
        password,
        cfg["sql_timeout_seconds"],
    )
    _ADB_MCP_TOKEN_PROVIDERS[key] = provider
    return provider


def _adb_mcp_password(cfg):
    password = cfg.get("adb_mcp_password", "")
    if password:
        return password

    secret_region = (
        cfg.get("adb_mcp_password_secret_region")
        or cfg["adb_mcp_region"]
    )
    auth = make_iam_auth(
        cfg["oci_config_file"],
        cfg["oci_config_profile"],
        secret_region,
        cfg.get("oci_auth_mode"),
    )
    return read_secret_value(
        cfg["adb_mcp_password_secret_ocid"],
        auth,
        cfg["sql_timeout_seconds"],
    )


def _empty_result(status, columns=None, truncated=False):
    return {
        "status": status,
        "columns": columns or [],
        "rows": [],
        "truncated": truncated,
    }


def _error_result(status, exc):
    return {
        "status": status,
        "message": str(exc),
        "columns": [],
        "rows": [],
        "truncated": False,
    }


def notify_status(status_callback, message):
    logger.info(message)
    if status_callback:
        status_callback(message)
