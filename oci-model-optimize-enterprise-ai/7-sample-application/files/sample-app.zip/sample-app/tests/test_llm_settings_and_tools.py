import unittest
from unittest.mock import patch

import llm


class SettingsAndToolTests(unittest.TestCase):
    def test_response_options_always_include_sql_tool(self):
        cfg = {"max_output_tokens": 1000}

        options = llm.response_options("model", "question", cfg, conversation_id="conv_1")

        self.assertEqual(options["tools"][0]["type"], "function")
        self.assertEqual(options["tools"][0]["name"], llm.SQL_TOOL_NAME)

    def test_response_options_include_file_search_tool_for_vector_store(self):
        cfg = {
            "max_output_tokens": 1000,
            "vector_store_ids": ["vs_test"],
        }

        options = llm.response_options("model", "question", cfg, conversation_id="conv_1")

        self.assertEqual(options["instructions"], llm.CUSTOMER_SUPPORT_SYSTEM_PROMPT)
        self.assertEqual(options["tools"][0]["name"], llm.SQL_TOOL_NAME)
        self.assertEqual(
            options["tools"][1],
            {"type": "file_search", "vector_store_ids": ["vs_test"]},
        )

    def test_instructions_route_manual_questions_to_file_search(self):
        instructions = llm.response_instructions({"max_output_tokens": 1000})

        self.assertIn("use the attached image as the source", instructions)
        self.assertIn("Use the file_search tool for vehicle owner manual", instructions)
        self.assertIn("vehicle operation", instructions)
        self.assertIn(
            "Use query_vehicle_database only for current-customer database records",
            instructions,
        )

    def test_instructions_keep_refusals_terse_without_generic_next_steps(self):
        instructions = llm.response_instructions({"max_output_tokens": 1000})

        self.assertIn("Refusal and unavailable-information responses must be terse", instructions)
        self.assertIn("Do not add generic customer-service advice", instructions)
        self.assertIn("phone numbers", instructions)
        self.assertIn("dealership referrals", instructions)
        self.assertIn("unless they are directly supported by retrieved tool results", instructions)

    def test_response_options_include_customer_context_when_customer_id_is_set(self):
        cfg = {"max_output_tokens": 1000, "customer_id": 7}

        options = llm.response_options("model", "question", cfg, conversation_id="conv_1")

        self.assertIn("current authenticated customer_id is 7", options["instructions"])
        self.assertIn("customer_id = 7", options["instructions"])
        self.assertIn("their vehicle records", options["instructions"])
        self.assertIn("customer_id 7", options["tools"][0]["description"])

    def test_sql_tool_description_excludes_manual_and_phone_pairing_questions(self):
        description = llm.sql_tool_definition()["description"]

        self.assertIn("Use only for facts about the current customer's profile", description)
        self.assertIn("owned vehicle records", description)
        self.assertIn("Do not use for owner manual", description)
        self.assertIn("phone pairing", description)
        self.assertIn("infotainment", description)

    def test_settings_reads_api_key_config_and_sql_defaults(self):
        with patch.dict(
            "os.environ",
            {
                "OCI_GENAI_REGION": "us-chicago-1",
                "OCI_CONFIG_FILE": "/tmp/oci-config",
                "OCI_CONFIG_PROFILE": "WORKSHOP",
                "OCI_AUTH_MODE": "resource_principal",
                "OCI_GENAI_MODEL_ROUTING_ENABLED": "true",
                "OCI_GENAI_GUARDRAILS_COMPARTMENT_OCID": "guardrails-compartment",
                "OCI_GENAI_GUARDRAILS_LANGUAGE_CODE": "en",
                "OCI_GENAI_GUARDRAILS_PROMPT_INJECTION_THRESHOLD": "0.5",
                "OCI_GENAI_VECTOR_STORE_IDS": "vs_one, vs_two",
                "OCI_GENAI_SEMANTIC_STORE_OCID": "semantic-store",
                "OCI_ADB_MCP_REGION": "us-ashburn-1",
                "OCI_ADB_DATABASE_OCID": "database",
                "OCI_ADB_MCP_USERNAME": "mcp_user",
                "OCI_ADB_MCP_PASSWORD_SECRET_OCID": "password-secret",
                "OCI_ADB_MCP_PASSWORD_SECRET_REGION": "us-phoenix-1",
            },
            clear=True,
        ):
            cfg = llm.settings()

        self.assertEqual(cfg["oci_config_file"], "/tmp/oci-config")
        self.assertEqual(cfg["oci_config_profile"], "WORKSHOP")
        self.assertEqual(cfg["oci_auth_mode"], "resource_principal")
        self.assertTrue(cfg["model_routing_enabled"])
        self.assertEqual(cfg["guardrails_compartment_ocid"], "guardrails-compartment")
        self.assertEqual(cfg["guardrails_language_code"], "en")
        self.assertEqual(cfg["guardrails_prompt_injection_threshold"], 0.5)
        self.assertEqual(cfg["nl2sql_region"], "us-chicago-1")
        self.assertEqual(cfg["nl2sql_api_version"], "20260325")
        self.assertEqual(cfg["adb_mcp_username"], "mcp_user")
        self.assertEqual(cfg["adb_mcp_password_secret_ocid"], "password-secret")
        self.assertEqual(cfg["adb_mcp_password_secret_region"], "us-phoenix-1")
        self.assertEqual(cfg["adb_mcp_execute_tool"], "EXECUTE_SQL")
        self.assertEqual(cfg["adb_mcp_sql_argument"], "query")
        self.assertEqual(cfg["adb_mcp_offset_argument"], "offset")
        self.assertEqual(cfg["adb_mcp_limit_argument"], "limit")
        self.assertEqual(cfg["vector_store_ids"], ["vs_one", "vs_two"])

    def test_settings_defaults_guardrails_values(self):
        with patch.dict("os.environ", {}, clear=True):
            cfg = llm.settings()

        self.assertEqual(cfg["guardrails_compartment_ocid"], "")
        self.assertEqual(cfg["guardrails_language_code"], "en")
        self.assertEqual(cfg["guardrails_prompt_injection_threshold"], 1.0)

    def test_make_client_uses_user_principal_auth(self):
        with patch("llm.OciUserPrincipalAuth", return_value="auth") as auth_cls, patch(
            "llm.httpx.Client",
            return_value="http-client",
        ) as http_client_cls, patch("llm.OpenAI", return_value="openai-client") as openai_cls:
            client = llm.make_client(
                "us-ashburn-1",
                "project-ocid",
                "/tmp/oci-config",
                "WORKSHOP",
            )

        auth_cls.assert_called_once_with(
            config_file="/tmp/oci-config",
            profile_name="WORKSHOP",
        )
        http_client_cls.assert_called_once_with(auth="auth")
        openai_cls.assert_called_once_with(
            base_url="https://inference.generativeai.us-ashburn-1.oci.oraclecloud.com/openai/v1",
            project="project-ocid",
            http_client="http-client",
            api_key="not-used",
        )
        self.assertEqual(client, "openai-client")


    def test_make_client_uses_resource_principal_auth(self):
        with patch("llm.OciResourcePrincipalAuth", return_value="auth") as auth_cls, patch(
            "llm.OciUserPrincipalAuth",
        ) as user_auth_cls, patch(
            "llm.httpx.Client",
            return_value="http-client",
        ) as http_client_cls, patch("llm.OpenAI", return_value="openai-client") as openai_cls:
            client = llm.make_client(
                "us-ashburn-1",
                "project-ocid",
                "/tmp/oci-config",
                "WORKSHOP",
                "resource_principal",
            )

        auth_cls.assert_called_once_with()
        user_auth_cls.assert_not_called()
        http_client_cls.assert_called_once_with(auth="auth")
        openai_cls.assert_called_once_with(
            base_url="https://inference.generativeai.us-ashburn-1.oci.oraclecloud.com/openai/v1",
            project="project-ocid",
            http_client="http-client",
            api_key="not-used",
        )
        self.assertEqual(client, "openai-client")

    def test_model_routing_uses_cheaper_model_for_text_only_prompt(self):
        cfg = {
            "model_routing_enabled": True,
            "cheaper_model": "cheap-model",
        }

        self.assertEqual(llm.response_model("strong-model", cfg, []), "cheap-model")

    def test_model_routing_keeps_strong_model_for_image_prompt(self):
        cfg = {
            "model_routing_enabled": True,
            "cheaper_model": "cheap-model",
        }
        messages = [{"role": "user", "content": "inspect", "images": [{"data": "x"}]}]

        self.assertEqual(llm.response_model("strong-model", cfg, messages), "strong-model")


if __name__ == "__main__":
    unittest.main()
