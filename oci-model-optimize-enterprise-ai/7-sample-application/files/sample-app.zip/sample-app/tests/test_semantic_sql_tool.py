import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from semantic_sql_tool import (
    _ADB_MCP_TOKEN_PROVIDERS,
    _adb_mcp_token_provider,
    customer_scoped_question,
    _missing_config,
    query_database,
)


class SemanticSqlToolTests(unittest.TestCase):
    def setUp(self):
        _ADB_MCP_TOKEN_PROVIDERS.clear()

    def test_missing_config_returns_configuration_error(self):
        result = query_database("show appointments", {})

        self.assertEqual(result["status"], "configuration_error")
        self.assertEqual(result["columns"], [])
        self.assertEqual(result["rows"], [])
        self.assertFalse(result["truncated"])
        self.assertIn("OCI_GENAI_SEMANTIC_STORE_OCID", result["message"])

    def test_missing_config_accepts_vault_secret_password(self):
        missing = _missing_config(
            {
                "semantic_store_ocid": "semantic-store",
                "nl2sql_region": "us-ashburn-1",
                "nl2sql_api_version": "20260325",
                "adb_mcp_region": "us-ashburn-1",
                "adb_database_ocid": "database",
                "adb_mcp_username": "mcp_user",
                "adb_mcp_password_secret_ocid": "password-secret",
            }
        )

        self.assertEqual(missing, [])

    def test_token_provider_reads_password_from_vault_secret(self):
        cfg = {
            "adb_mcp_region": "us-ashburn-1",
            "adb_database_ocid": "database",
            "adb_mcp_username": "mcp_user",
            "adb_mcp_password": "",
            "adb_mcp_password_secret_ocid": "password-secret",
            "adb_mcp_password_secret_region": "us-phoenix-1",
            "oci_config_file": "/tmp/oci-config",
            "oci_config_profile": "WORKSHOP",
            "sql_timeout_seconds": 30,
        }

        with patch("semantic_sql_tool.make_iam_auth", return_value="auth") as make_auth, patch(
            "semantic_sql_tool.read_secret_value",
            return_value="vault-password",
        ) as read_secret:
            provider = _adb_mcp_token_provider(cfg)

        self.assertEqual(provider.password, "vault-password")
        make_auth.assert_called_once_with(
            "/tmp/oci-config",
            "WORKSHOP",
            "us-phoenix-1",
            None,
        )
        read_secret.assert_called_once_with("password-secret", "auth", 30)

    def test_customer_scoped_question_adds_customer_filter_instruction(self):
        scoped = customer_scoped_question("show my appointments", 7)

        self.assertIn("show my appointments", scoped)
        self.assertIn("authenticated customer_id is 7", scoped)
        self.assertIn("customer_id = 7", scoped)

    def test_query_database_sends_customer_scoped_question_to_nl2sql(self):
        cfg = self.complete_cfg(customer_id=7)
        statuses = []
        nl2sql = Mock()
        nl2sql.generate_sql.return_value = SimpleNamespace(
            status="ok",
            sql="SELECT * FROM vehicles WHERE customer_id = 7",
            request_id="request-id",
        )
        adb = Mock()
        adb.execute_sql.return_value = SimpleNamespace(
            columns=["vehicle_id"],
            rows=[{"vehicle_id": 123}],
            truncated=False,
        )

        with patch("semantic_sql_tool.make_iam_auth", return_value="auth"), patch(
            "semantic_sql_tool.Nl2SqlClient",
            return_value=nl2sql,
        ), patch("semantic_sql_tool._adb_mcp_token_provider", return_value="token"), patch(
            "semantic_sql_tool.AdbMcpClient",
            return_value=adb,
        ):
            result = query_database(
                "show my vehicle",
                cfg,
                status_callback=statuses.append,
            )

        self.assertEqual(result["status"], "ok")
        self.assertEqual(
            statuses,
            [
                "Calling NL2SQL function...",
                "Received SQL query from NL2SQL.",
                "Calling ADB MCP server...",
                "Received data from ADB MCP server.",
            ],
        )
        nl2sql.generate_sql.assert_called_once()
        scoped_question = nl2sql.generate_sql.call_args.args[0]
        self.assertIn("show my vehicle", scoped_question)
        self.assertIn("customer_id = 7", scoped_question)
        adb.execute_sql.assert_called_once_with(
            "SELECT * FROM vehicles WHERE customer_id = 7"
        )

    def test_query_database_rejects_generated_sql_without_customer_scope(self):
        cfg = self.complete_cfg(customer_id=7)
        nl2sql = Mock()
        nl2sql.generate_sql.return_value = SimpleNamespace(
            status="ok",
            sql="SELECT * FROM vehicles",
            request_id="request-id",
        )

        with patch("semantic_sql_tool.make_iam_auth", return_value="auth"), patch(
            "semantic_sql_tool.Nl2SqlClient",
            return_value=nl2sql,
        ), patch("semantic_sql_tool.AdbMcpClient") as adb_client:
            result = query_database("show my vehicle", cfg)

        self.assertEqual(result["status"], "guardrail_rejected")
        self.assertIn("customer_id = 7", result["message"])
        adb_client.assert_not_called()

    def complete_cfg(self, customer_id=None):
        return {
            "semantic_store_ocid": "semantic-store",
            "nl2sql_region": "us-ashburn-1",
            "nl2sql_api_version": "20260325",
            "adb_mcp_region": "us-ashburn-1",
            "adb_database_ocid": "database",
            "adb_mcp_username": "mcp_user",
            "adb_mcp_password": "password",
            "adb_mcp_password_secret_ocid": "",
            "adb_mcp_password_secret_region": "",
            "adb_mcp_execute_tool": "EXECUTE_SQL",
            "adb_mcp_sql_argument": "query",
            "adb_mcp_offset_argument": "offset",
            "adb_mcp_limit_argument": "limit",
            "sql_max_rows": 50,
            "sql_timeout_seconds": 30,
            "oci_config_file": "/tmp/oci-config",
            "oci_config_profile": "WORKSHOP",
            "customer_id": customer_id,
        }


if __name__ == "__main__":
    unittest.main()
