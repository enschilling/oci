import logging
import random

import streamlit as st

from chat_rendering import render_chat
from llm import create_conversation
from llm import make_client as create_client
from llm import settings, stream_response
from prompt_injection_guardrails import check_prompt_injection
from prompt_images import PromptImageError, capture_uploaded_image


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("oci-llm-chat")
CUSTOMER_ID_MIN = 1
CUSTOMER_ID_MAX = 10
CUSTOMER_ID_STATE_KEY = "customer_id"
CONVERSATION_ID_STATE_KEY = "conversation_id"
IMAGE_UPLOADER_KEY_STATE = "image_uploader_key"


@st.cache_resource(show_spinner=False)
def make_client(region, project_ocid, config_file, config_profile, auth_mode):
    return create_client(region, project_ocid, config_file, config_profile, auth_mode)


def submit_prompt():
    prompt = st.session_state.draft.strip()
    if not prompt or st.session_state.busy:
        return

    try:
        prompt_image = capture_uploaded_image(
            st.session_state.get(prompt_image_widget_key())
        )
    except PromptImageError as exc:
        st.session_state.messages.append({"role": "error", "content": f"Error: {exc}"})
        return

    message = {"role": "user", "content": prompt}
    if prompt_image:
        message["images"] = [prompt_image.as_dict()]

    st.session_state.messages.append(message)
    st.session_state.pending_prompt = prompt
    st.session_state.draft = ""
    st.session_state[IMAGE_UPLOADER_KEY_STATE] += 1
    st.session_state.busy = True


def ensure_state():
    st.session_state.setdefault("messages", [])
    st.session_state.setdefault("busy", False)
    st.session_state.setdefault("pending_prompt", None)
    st.session_state.setdefault(CONVERSATION_ID_STATE_KEY, "")
    st.session_state.setdefault(IMAGE_UPLOADER_KEY_STATE, 0)
    if CUSTOMER_ID_STATE_KEY not in st.session_state:
        st.session_state[CUSTOMER_ID_STATE_KEY] = random.randint(
            CUSTOMER_ID_MIN,
            CUSTOMER_ID_MAX,
        )


def prompt_image_widget_key():
    return f"prompt_image_{st.session_state[IMAGE_UPLOADER_KEY_STATE]}"


def clear_pending_request():
    st.session_state.pending_prompt = None


def conversation_id(client):
    if not st.session_state[CONVERSATION_ID_STATE_KEY]:
        st.session_state[CONVERSATION_ID_STATE_KEY] = create_conversation(client)
    return st.session_state[CONVERSATION_ID_STATE_KEY]


def run_pending_request(chat_slot, cfg):
    prompt = st.session_state.pending_prompt
    if not prompt:
        return
    cfg = {**cfg, "customer_id": st.session_state[CUSTOMER_ID_STATE_KEY]}
    assistant_message_index = None

    def update_assistant_message(content):
        nonlocal assistant_message_index
        if assistant_message_index is None:
            st.session_state.messages.append({"role": "assistant", "content": content})
            assistant_message_index = len(st.session_state.messages) - 1
        else:
            st.session_state.messages[assistant_message_index]["content"] = content

        with chat_slot:
            render_chat(st.session_state.messages, thinking=True)

    def update_guardrails_status(content):
        logger.info(content)
        update_assistant_message(content)

    try:
        request_messages = list(st.session_state.messages)
        update_guardrails_status("Calling OCI ApplyGuardrails API...")
        try:
            guardrail_check = check_prompt_injection(prompt, cfg)
        except Exception as exc:
            update_guardrails_status(f"OCI ApplyGuardrails result: error={exc}")
            raise

        guardrails_result_message = (
            "OCI ApplyGuardrails result: "
            f"promptInjection.score={guardrail_check.score}, "
            f"blocked={guardrail_check.blocked}"
        )
        if guardrail_check.blocked:
            logger.warning(
                "OCI ApplyGuardrails blocked prompt injection risk score=%s",
                guardrail_check.score,
            )
            update_guardrails_status(
                f"{guardrail_check.message}\n\n"
                f"{guardrails_result_message}"
            )
        else:
            update_guardrails_status(guardrails_result_message)
            client = make_client(
                cfg["region"],
                cfg["project_ocid"],
                cfg["oci_config_file"],
                cfg["oci_config_profile"],
                cfg["oci_auth_mode"],
            )
            current_conversation_id = conversation_id(client)
            answer_started = False

            for answer in stream_response(
                client,
                cfg["model"],
                prompt,
                cfg,
                request_messages,
                status_callback=update_assistant_message,
                conversation_id=current_conversation_id,
            ):
                answer_started = True

                update_assistant_message(answer)

            if not answer_started:
                logger.warning("OCI Responses API completed without returning any text")
                update_assistant_message("(No text returned.)")

    except Exception as exc:
        logger.exception("Failed while handling LLM request")
        st.session_state.messages.append({"role": "error", "content": f"Error: {exc}"})

    clear_pending_request()
    st.session_state.busy = False
    st.rerun()


def main():
    st.set_page_config(page_title="OCI LLM Chat", page_icon=":speech_balloon:")
    ensure_state()
    cfg = settings()

    st.title("OCI LLM Chat")
    st.caption(
        f"Customer ID: {st.session_state[CUSTOMER_ID_STATE_KEY]} | "
        f"LLM: {cfg['model'] or 'not configured'}"
    )
    chat_slot = st.empty()
    with chat_slot:
        render_chat(st.session_state.messages, thinking=st.session_state.busy)

    st.text_area("Message", key="draft", height=100, disabled=st.session_state.busy)
    st.file_uploader(
        "Attach image",
        type=["png", "jpg", "jpeg", "webp"],
        accept_multiple_files=False,
        key=prompt_image_widget_key(),
        disabled=st.session_state.busy,
    )
    st.button("Send", on_click=submit_prompt, disabled=st.session_state.busy)

    missing = [name for name in ("region", "project_ocid") if not cfg[name]]
    if missing:
        error = "Missing configuration: " + ", ".join(missing)
        logger.error(error)
        if st.session_state.pending_prompt:
            st.session_state.messages.append({"role": "error", "content": f"Error: {error}"})
            clear_pending_request()
            st.session_state.busy = False
            st.rerun()
        st.error(error)
        return

    run_pending_request(chat_slot, cfg)


if __name__ == "__main__":
    main()
