import re


class SqlGuardrailError(ValueError):
    pass


BLOCKED_KEYWORDS_RE = re.compile(
    r"\b(insert|update|delete|merge|drop|alter|create|truncate|grant|revoke|begin|declare|execute)\b",
    re.IGNORECASE,
)
READ_ONLY_START_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE)
CUSTOMER_ID_FILTER_RE = re.compile(
    r"\bcustomer_id\b\s*=\s*'?(\d+)'?"
    r"|'?(\d+)'?\s*=\s*\bcustomer_id\b"
    r"|\bcustomer_id\b\s+in\s*\(\s*'?(\d+)'?\s*\)",
    re.IGNORECASE,
)
CUSTOMER_SCOPE_BLOCKED_RE = re.compile(r"\b(or|union|minus|intersect)\b", re.IGNORECASE)


def validate_read_only_sql(sql):
    normalized = (sql or "").strip()
    if not normalized:
        raise SqlGuardrailError("Generated SQL was empty.")

    if normalized.endswith(";"):
        normalized = normalized[:-1].strip()

    if ";" in normalized:
        raise SqlGuardrailError("Generated SQL contains multiple statements.")

    if not READ_ONLY_START_RE.search(normalized):
        raise SqlGuardrailError("Generated SQL must start with SELECT or WITH.")

    blocked = BLOCKED_KEYWORDS_RE.search(normalized)
    if blocked:
        raise SqlGuardrailError(
            f"Generated SQL contains a blocked keyword: {blocked.group(1).lower()}."
        )

    return normalized


def validate_customer_scope(sql, customer_id):
    expected = normalized_customer_id(customer_id)
    if not expected:
        return sql

    blocked = CUSTOMER_SCOPE_BLOCKED_RE.search(sql)
    if blocked:
        raise SqlGuardrailError(
            f"Generated SQL contains {blocked.group(1).upper()}, which is not "
            "allowed with customer scoping."
        )

    found_scope = False
    for match in CUSTOMER_ID_FILTER_RE.finditer(sql):
        matched_ids = [value for value in match.groups() if value is not None]
        if not any(normalized_customer_id(value) == expected for value in matched_ids):
            raise SqlGuardrailError(
                f"Generated SQL must not filter to a customer_id other than {expected}."
            )
        found_scope = True

    if found_scope:
        return sql

    raise SqlGuardrailError(
        f"Generated SQL must filter results to customer_id = {expected}."
    )


def normalized_customer_id(customer_id):
    raw = "" if customer_id is None else str(customer_id).strip()
    if not raw:
        return ""
    try:
        return str(int(raw))
    except ValueError as exc:
        raise SqlGuardrailError("Customer ID must be numeric.") from exc
